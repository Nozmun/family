# AmaarBazar — আমারবাজার

Bangladesh's free local classifieds marketplace. Buy, sell and connect —
vehicles, property, electronics, jobs and more. Fully bilingual
(English ⇄ বাংলা), prices in BDT (৳), with a bKash / Nagad / Rocket / card
checkout flow.

## Run locally
Open `index.html` in a browser, or serve the folder:
```bash
python3 -m http.server 8000   # then visit http://localhost:8000
```

## Pages
- `index.html` — homepage (hero, categories, featured listings, how-it-works, promo, trust, app)
- `browse.html` — listings with live category/price/location filters + sorting
- `post.html` — post an ad + Featured/Premium upgrade checkout

## Deployment
Pushing to `main` auto-deploys to GitHub Pages via `.github/workflows/deploy.yml`.

## Connecting a custom domain
Add a file named `CNAME` at the repo root containing just your domain
(e.g. `amaarbazar.com`), then set the domain under Settings → Pages.

## Payments
The checkout UI/flow is complete and validated. Processing real payments
requires a backend integration with a payment gateway (bKash Merchant API
or Stripe) to handle the transaction and secret keys.
